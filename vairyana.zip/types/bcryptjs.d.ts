declare module "bcryptjs";


